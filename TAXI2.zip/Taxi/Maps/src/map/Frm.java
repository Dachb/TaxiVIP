package map;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;

import javax.lang.model.element.Element;
import javax.swing.*;
import javax.swing.text.Document;
import javax.xml.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Frm extends JFrame implements ActionListener{
		private JButton b1;
		private Container c;
		private JTextField jTextField1,jTextField2,jTextField3;
		private JPanel j;
		
		
		public Frm() {
			c = this.getContentPane();
			b1 = new JButton("Boton");
			jTextField1 = new JTextField(30);
			jTextField2 = new JTextField(30);
			jTextField3 = new JTextField(30);
			b1.addActionListener(this);
			j = new JPanel();
			j.setLayout((new GridLayout(2,2)));
			c.setLayout(new BorderLayout());
			c.add(BorderLayout.SOUTH,b1);
			j.add(jTextField1);
			j.add(jTextField2);
			j.add(jTextField3);
			c.add(BorderLayout.CENTER,j);
			this.setVisible(true);
			this.setSize(500,500);

			
		}
		

		
		public void actionPerformed(ActionEvent e)
	    {
			if (e.getSource()==b1) {
				String address = jTextField1.getText();

				// find coordinates
				String coords = getCoordinates(address);

				if (coords!=null)
				{
					String [] coord = null;
	            	coord = coords.split(",");

	            	jTextField2.setText(coord[0]);
	            	jTextField3.setText(coord[1]);
				}
			}
	    }
		
		public String getCoordinates(String c)
	    {
	        try
	        {
	            String thisLine;
	            String adresa = c;
	            adresa = adresa.replace(' ', '+');
	            URL u = new URL("http://maps.googleapis.com/maps/api/geocode/xml?address="+adresa+",+CA&sensor=true_or_false");

	            BufferedReader theHTML = new BufferedReader(new InputStreamReader(u.openStream()));

	            FileWriter fstream = new FileWriter("url.xml");
	            BufferedWriter out = new BufferedWriter(fstream);
	            while ((thisLine = theHTML.readLine()) != null)
	                out.write(thisLine);
	            out.close();

	            File file = new File("url.xml");
	            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	            DocumentBuilder db = dbf.newDocumentBuilder();
	            Document doc = (Document) db.parse(file);
	            ((Node) doc.getDefaultRootElement()).normalize();
	            NodeList nl = ((org.w3c.dom.Document) doc).getElementsByTagName("code");
	            Element n = (Element)nl.item(0);
	            String st = ((Node) n).getFirstChild().getNodeValue();

	            if (st.equals("200"))
	            {
	                NodeList n2 = ((org.w3c.dom.Document) doc).getElementsByTagName("coordinates");
	                Element nn = (Element)n2.item(0);
	                String st1 = ((Node) nn).getFirstChild().getNodeValue();

	                return st1;
	            }
	            else
	            {
	                return null;
	            }
	        }
	        catch (MalformedURLException e) {
	            JOptionPane.showMessageDialog(this, "error="+e.getMessage());
	            return null;
	        }
	        catch (IOException e) {
	            JOptionPane.showMessageDialog(this, "error="+e.getMessage());
	             return null;
	        }
	        catch (Exception e) {
	            JOptionPane.showMessageDialog(this, "error="+e.getMessage());
	             return null;
	        }
	    }
		
	

}