package entity;

public class Persona {
	private int idPersona;
	private String Nombre;
	private String Apellido;
	private String Sexo;
	private String Email;
	private String Pais;
	private String Estado;
	private String Municipio;
	private String Colonia;
	private int CodigoPostal;
	private int Telefono;
	private int Numero;
	private String Nacionalidad;
	private String Calle;

	
	public Persona() {
		super();
	}

	public Persona(int idPersona, String nombre, String apellido, String sexo,
			String email, String pais, String estado, String municipio,
			String colonia, int codigoPostal, int telefono, int numero, String nacionalidad, String calle) {
		super();
		this.idPersona = idPersona;
		Nombre = nombre;
		Apellido = apellido;
		Sexo = sexo;
		Email = email;
		Pais = pais;
		Estado = estado;
		Municipio = municipio;
		Colonia = colonia;
		CodigoPostal = codigoPostal;
		Telefono = telefono;
		Nacionalidad = nacionalidad;
		Numero = numero;
		Calle = calle;
		
	}

	public int getIdPersona() {
		return idPersona;
	}

	public void setIdPersona(int idPersona) {
		this.idPersona = idPersona;
	}

	public String getNombre() {
		return Nombre;
	}

	public void setNombre(String nombre) {
		Nombre = nombre;
	}

	public String getApellido() {
		return Apellido;
	}

	public void setApellido(String apellido) {
		Apellido = apellido;
	}

	public String getSexo() {
		return Sexo;
	}

	public void setSexo(String sexo) {
		Sexo = sexo;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getPais() {
		return Pais;
	}

	public void setPais(String pais) {
		Pais = pais;
	}

	public String getEstado() {
		return Estado;
	}

	public void setEstado(String estado) {
		Estado = estado;
	}

	public String getMunicipio() {
		return Municipio;
	}

	public void setMunicipio(String municipio) {
		Municipio = municipio;
	}

	public String getColonia() {
		return Colonia;
	}

	public void setColonia(String colonia) {
		Colonia = colonia;
	}

	public int getCodigoPostal() {
		return CodigoPostal;
	}

	public void setCodigoPostal(int codigoPostal) {
		CodigoPostal = codigoPostal;
	}

	public int getTelefono() {
		return Telefono;
	}

	public void setTelefono(int telefono) {
		Telefono = telefono;
	}

	public int getNumero() {
		return Numero;
	}

	public void setNumero(int numero) {
		Numero = numero;
	}
	
	public String getNacionalidad() {
		return Nacionalidad;
	}

	public void setNacionalidad(String nacionalidad) {
		Nacionalidad = nacionalidad;
	}
	
	public String getCalle() {
		return Calle;
	}

	public void setCalle(String calle) {
		Calle = calle;
	}
	
	
}
