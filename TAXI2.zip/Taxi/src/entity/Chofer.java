package entity;

public class Chofer extends Persona{
	private int idChofer;
	private int idTaxi;
	
	public Chofer() {
		super();
	}

	public Chofer(int idChofer, int idTaxi, int idPersona, String Nombre, String Apellido, String Sexo, String Email, String Pais, String Estado, String Municipio, String Colonia, int CodigoPostal, int Telefono, int Numero, String Nacionalidad, String Calle) {
		super(idPersona, Nombre, Apellido, Sexo, Email, Pais, Estado, Municipio, Colonia, CodigoPostal, Telefono, Numero, Nacionalidad, Calle);
		this.idChofer = idChofer;
		this.idTaxi = idTaxi;
	}

	public int getIdChofer() {
		return idChofer;
	}

	public void setIdChofer(int idChofer) {
		this.idChofer = idChofer;
	}

	public int getIdTaxi() {
		return idTaxi;
	}

	public void setIdTaxi(int idTaxi) {
		this.idTaxi = idTaxi;
	}
	
	
	
}
