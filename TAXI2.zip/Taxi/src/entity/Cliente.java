package entity;

public class Cliente extends Persona{
	private String Usuario;
	private String Contrase�a;
	private int idCliente;
	
	public Cliente() {
		super();
	}

	public Cliente(String usuario, String contrase�a, int idCliente, int idPersona, String Nombre, String Apellido, String Sexo, String Email, String Pais, String Estado, String Municipio, String Colonia, int CodigoPostal, int Telefono, int Numero, String Nacionalidad, String Calle) {
		super(idPersona, Nombre, Apellido, Sexo, Email, Pais, Estado, Municipio, Colonia, CodigoPostal, Telefono, Numero, Nacionalidad, Calle);
		Usuario = usuario;
		Contrase�a = contrase�a;
		this.idCliente = idCliente;
	}

	public String getUsuario() {
		return Usuario;
	}

	public void setUsuario(String usuario) {
		Usuario = usuario;
	}

	public String getContrase�a() {
		return Contrase�a;
	}

	public void setContrase�a(String contrase�a) {
		Contrase�a = contrase�a;
	}

	public int getIdCliente() {
		return idCliente;
	}

	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}
	
	
	
}
