package boundary;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import entity.*;
import dibujarimagen.*;
import control.ControlAcceso;

public class FrmIngreso extends JFrame implements ActionListener, MouseListener {
	private JLabel lLogin, lPassword, lRegistro;
	private JTextField tLogin;
	private JPasswordField tPassword;
	private Container c;
	private JButton bIngresar;
	private JPanel panelFormulario, panelBotones;
	private FrmRegistro frmRegistro;
	private frameimagen Frimg;
	
	public FrmIngreso()
	{
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		catch(UnsupportedLookAndFeelException e){
			e.printStackTrace();
		}
		catch(ClassNotFoundException e){
			e.printStackTrace();
		}
		catch(InstantiationException e){
			e.printStackTrace();
		}
		catch(IllegalAccessException e){
			e.printStackTrace();
		}
		c = this.getContentPane();
		c.setLayout(new BorderLayout());
		
		panelFormulario = new JPanel();
		panelFormulario.setLayout(new GridLayout(2,2));
		lLogin = new JLabel("Login");
		lPassword = new JLabel("Password");
		lRegistro = new JLabel("�No eres usuario?");
		tLogin = new JTextField(20);
		tPassword = new JPasswordField(20);
		panelFormulario.add(lLogin);
		panelFormulario.add(tLogin);
		panelFormulario.add(lPassword);
		panelFormulario.add(tPassword);
		
		panelBotones = new JPanel();
		panelBotones.setLayout(new BorderLayout());
		bIngresar = new JButton("Ingresar");
		bIngresar.addActionListener(this);
		bIngresar.setBounds(0, 0, 15, 20);
		/*bCrearTabla = new JButton("Crear Tabla");
		bCrearTabla.addActionListener(this);
		bBorrarTabla = new JButton("Borrar Tabla");
		bBorrarTabla.addActionListener(this);*/
		
		panelBotones.add(BorderLayout.WEST,bIngresar);
		panelBotones.add(BorderLayout.SOUTH,lRegistro);
		lRegistro.setForeground(Color.BLUE);
		lRegistro.addMouseListener(this); 
		//panelBotones.add(bCrearTabla);
		//panelBotones.add(bBorrarTabla);
		
		c.add(BorderLayout.CENTER,panelFormulario);
		c.add(BorderLayout.SOUTH,panelBotones);
		
		pack();
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setVisible(true);
	}


	
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==bIngresar) {
			Cliente cliente = new Cliente();
			cliente.setUsuario(tLogin.getText());
			String password = new String(tPassword.getPassword());
			cliente.setContrase�a(password);
					
			ControlAcceso control = new ControlAcceso();
			boolean resultado = control.validarIngreso(cliente);
			
			
			if(resultado == true) {
				JOptionPane.showMessageDialog(null, "Usuario v�lido");
				Frimg = new frameimagen();
				this.setVisible(false);
				//frmPrincipal = new FrmPrincipal();
			}
			if(resultado == false) {
				JOptionPane.showMessageDialog(null, "Usuario Inv�lido");
			}
		}
	}
	



	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		setVisible(false);
		frmRegistro = new FrmRegistro();
		//JOptionPane.showMessageDialog(null, "Click");
		
	}



	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	
	public static void main(String args[])
	{
		//FrmPrincipal app2 = new FrmPrincipal();
		FrmIngreso app = new FrmIngreso();
	}

}
