package boundary;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import control.*;
import entity.*;

public class FrmRegistro extends JFrame implements ActionListener{
	private JPanel panelInferior, panelMatriz;
	private JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l0;
	private JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13;
	private JCheckBox check1, check2;
	private JButton b1;
	private Container c;
	private ControlRegistro control;
	public FrmRegistro() {
		
		super();
		control = new ControlRegistro();
		c = this.getContentPane();
		
		l1 = new JLabel("Nombre");
		l2 = new JLabel("Apellido");
		l3 = new JLabel("Sexo");
		l4 = new JLabel("Email");
		l5 = new JLabel("Pais");
		l6 = new JLabel("Estado");
		l7 = new JLabel("Municipio");
		l8 = new JLabel("Colonia");
		l9 = new JLabel("Codigo Postal");
		l10 = new JLabel("Telefono");
		l11 = new JLabel("Nacionalidad");
		l12 = new JLabel("Usuario");
		l13 = new JLabel("Contrase�a");
		l0 = new JLabel("");
		
		t1 = new JTextField(20);
		t2 = new JTextField(20);
		t3 = new JTextField(20);
		t4 = new JTextField(20);
		t5 = new JTextField(20);
		t6 = new JTextField(20);
		t7 = new JTextField(20);
		t8 = new JTextField(20);
		t9 = new JTextField(20);
		t10 = new JTextField(20);
		t11 = new JTextField(20);
		t12 = new JTextField(20);
		t13 = new JTextField(20);
		
		check1 = new JCheckBox("Masculino");
		check2 = new JCheckBox("Femenino");
		
		
		b1 = new JButton("Registrarse");
		b1.addActionListener(this);
		
		
		panelInferior = new JPanel();
		panelInferior.setLayout(new FlowLayout());
		panelMatriz = new JPanel();
		panelMatriz.setLayout(new GridLayout(7,4));
		
		panelMatriz.add(l1);
		panelMatriz.add(t1);
		panelMatriz.add(l2);
		panelMatriz.add(t2);
		panelMatriz.add(l3);
		panelMatriz.add(check1);
		panelMatriz.add(check2);
		panelMatriz.add(l0);
		panelMatriz.add(l4);
		panelMatriz.add(t4);
		panelMatriz.add(l5);
		panelMatriz.add(t5);
		panelMatriz.add(l6);
		panelMatriz.add(t6);
		panelMatriz.add(l7);
		panelMatriz.add(t7);
		panelMatriz.add(l8);
		panelMatriz.add(t8);
		panelMatriz.add(l9);
		panelMatriz.add(t9);
		panelMatriz.add(l10);
		panelMatriz.add(t10);
		panelMatriz.add(l11);
		panelMatriz.add(t11);
		panelMatriz.add(l12);
		panelMatriz.add(t12);
		panelMatriz.add(l13);
		panelMatriz.add(t13);

		panelInferior.add(b1);

		
		c.setLayout(new BorderLayout());
		c.add(panelMatriz,BorderLayout.CENTER);
		c.add(panelInferior,BorderLayout.SOUTH);
		
		this.pack();
		this.setVisible(true);
	}

	
	public void actionPerformed(ActionEvent e) 
	{
		boolean clear = false;
		if(e.getSource()==b1)//registrarse
		{
			Cliente cliente = new Cliente();
			cliente.setNombre(t1.getText());
			cliente.setApellido(t2.getText());
			if(check1.isSelected()) {
				cliente.setSexo("Masculino");
			}
			else if(check2.isSelected()) {
				cliente.setSexo("Femenino");
				check1.setSelected(true);
			}
			cliente.setEmail(t4.getText());
			cliente.setPais(t5.getText());
			cliente.setEstado(t6.getText());
			cliente.setMunicipio(t7.getText());
			cliente.setColonia(t8.getText());
			cliente.setCodigoPostal(Integer.parseInt(t9.getText()));
			cliente.setTelefono(Integer.parseInt(t10.getText()));
			cliente.setNacionalidad(t11.getText());
			cliente.setUsuario(t12.getText());
			cliente.setContrase�a(t13.getText());
			control.nuevoUsuario(cliente);
			JOptionPane.showMessageDialog(null, "Cliente Agregado");
			clear = true;
		}
		if(clear){
			t1.setText("");
			t2.setText("");
			t3.setText("");
			t4.setText("");
			t5.setText("");
			t6.setText("");
			t7.setText("");
			t8.setText("");
		}
	}
}