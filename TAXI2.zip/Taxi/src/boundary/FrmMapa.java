package boundary;


import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

import javax.swing.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.JFrame;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import org.jdesktop.swingx.JXMapViewer;
import org.jdesktop.swingx.OSMTileFactoryInfo;
import org.jdesktop.swingx.mapviewer.DefaultTileFactory;
import org.jdesktop.swingx.mapviewer.DefaultWaypoint;
import org.jdesktop.swingx.mapviewer.TileFactoryInfo;
import org.jdesktop.swingx.mapviewer.GeoPosition;
import org.jdesktop.swingx.mapviewer.Waypoint;
import org.jdesktop.swingx.mapviewer.WaypointPainter;

import org.jdesktop.swingx.painter.Painter;
import org.jdesktop.swingx.painter.CompoundPainter;
import org.xml.sax.SAXException;

import control.*;

public class FrmMapa extends JFrame implements ActionListener{
	private JXMapViewer mapViewer;
	private JPanel panelMatriz;
	private JLabel l1,l2;
	private JTextField t1,t2;
	private JComboBox cb1;
	private JButton b1;
	private Container c;
	private double latitud, longitud;
	private String Nombre;
	private String Direccion;
	private int contador;
	private Geocoding geocoding;
	
	public FrmMapa()
	{
		//Se crea el objeto mapa que permite realizar el enlace con OSM
		mapViewer = new JXMapViewer();		
		//control.crearTabla();
		//control.insertarPosicion();
		
		c = this.getContentPane();
		l1 = new JLabel("Direcci�n");
		t1 = new JTextField(50);
		b1 = new JButton("Consultar");
		b1.addActionListener(this);
		panelMatriz = new JPanel();
		panelMatriz.add(cb1);
		/*panelMatriz.add(l1);
		panelMatriz.add(t1);
		panelMatriz.add(l2);
		panelMatriz.add(t2);
		panelMatriz.add(b1);*/
		
		c.setLayout(new BorderLayout());
		c.add(panelMatriz,BorderLayout.NORTH);
		c.add(mapViewer,BorderLayout.CENTER);
		
		
		this.setSize(400, 600);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}
	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==b1) {
			Direccion = t1.getText();
			geocoding = new Geocoding();
			try {
				geocoding.Geocode(Direccion);
			} catch (XPathExpressionException | IOException
					| ParserConfigurationException | SAXException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			prepararMapa(latitud, longitud);
		}
	}
	public void prepararMapa(double latitud, double longitud)
	{
		//Se define el n�mero de segmentos en los cuales ser� recuperada la informaci�n del mapa
				TileFactoryInfo info = new OSMTileFactoryInfo();
				DefaultTileFactory tileFactory = new DefaultTileFactory(info);
				tileFactory.setThreadPoolSize(8);
				mapViewer.setTileFactory(tileFactory);
				
				//Se definen las posiciones geogr�ficas que ser�n utilizadas [El formato es latitud, longitud]
				GeoPosition zona = new GeoPosition(latitud,longitud);
				

				mapViewer.setZoom(5);
				mapViewer.setAddressLocation(zona);
				
				//Se genera una colecci�n con los puntos que quieren ser mostrados en el mapa
				Set<Waypoint> waypoints = new HashSet<Waypoint>(Arrays.asList(
						new DefaultWaypoint(zona)));
				
				//Se genera el objeto responsable de pintar los marcadores
				WaypointPainter<Waypoint> waypointPainter = new WaypointPainter<Waypoint>();
				waypointPainter.setWaypoints(waypoints);
				
				//Se genera una colecci�n con los pintadores de marcadores
				List<Painter<JXMapViewer>> painters = new ArrayList<Painter<JXMapViewer>>();
				painters.add(waypointPainter);
				
				//Se manda pintar los marcadores sobre el mapa
				CompoundPainter<JXMapViewer> painter = new CompoundPainter<JXMapViewer>(painters);
				mapViewer.setOverlayPainter(painter);
	}
}
