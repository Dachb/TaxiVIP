package control;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import entity.*;

public class ControlRegistro {
	private Connection con;
	
	public int nuevoUsuario(Cliente cliente){
		int result = 0;
		int idp = 0;
		int idc =0;
		boolean correo=Correo(cliente);
		if(correo==false) {
			try{
				idp = IdPersona();
				idc = IdCliente();
				conectar();
				PreparedStatement InsertarP = con.prepareStatement("INSERT INTO Persona VALUES (?,?,?,?,?,?,?,?,?,?,?)");
				InsertarP.setInt(1, idp);
				InsertarP.setString(2, cliente.getNombre());
				InsertarP.setString(3, cliente.getApellido());
				InsertarP.setString(4, cliente.getSexo());
				InsertarP.setInt(5, cliente.getNumero());
				InsertarP.setInt(6, cliente.getCodigoPostal());
				InsertarP.setString(7, cliente.getMunicipio());
				InsertarP.setString(8, cliente.getEstado());
				InsertarP.setString(9, cliente.getPais());
				InsertarP.setString(10, cliente.getCalle());
				InsertarP.setString(11, cliente.getColonia());
				InsertarP.executeUpdate();
				PreparedStatement InsertarC = con.prepareStatement("INSERT INTO Cliente VALUES (?,?,?,?,?,?)");
				InsertarC.setInt(1, idc);
				InsertarC.setInt(2, idp);
				InsertarC.setNull(3, java.sql.Types.INTEGER);
				InsertarC.setNull(4, java.sql.Types.INTEGER);
				InsertarC.setString(5, cliente.getUsuario());
				InsertarC.setString(6, cliente.getContrase�a());
				InsertarC.executeUpdate();
				System.out.println("Usuario agregado");
			}
			catch(SQLException e){
				System.out.println(e.getMessage());
			}
		}
		return result;
	}	
	
	public boolean Correo(Cliente cliente) {
		boolean result = false;
		try{
			conectar();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Persona1 WHERE Correo ='"+cliente.getEmail()+"'");
			while(rs.next()){
				result=true;
			}
		}
		catch(SQLException e){
			System.out.println(e.getMessage());
		}
		return result;
	}
	
	public int IdPersona() {
		int result = 0;
		try{
			conectar();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT COUNT(IdPersona) FROM Persona");
			while(rs.next()){
				result=rs.getInt(1);
			}
		}
		catch(SQLException e){
			System.out.println(e.getMessage());
		}
		return result+1;
	}
	
	public int IdCliente() {
		int result = 0;
		try{
			conectar();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT COUNT(IdCliente) FROM Cliente");
			while(rs.next()){
				result=rs.getInt(1);
			}
		}
		catch(SQLException e){
			System.out.println(e.getMessage());
		}
		return result+1;
	}
	
	public void conectar()
	{
		try
		{
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			String connectionUrl = "jdbc:sqlserver://148.239.60.34;" + 
							"databaseName=pfTaxiBautista;user=ids;password=ids4010;";
			con = DriverManager.getConnection(connectionUrl);
			System.out.println("Conectado");
		}
		catch(ClassNotFoundException cnfe)
		{
			System.out.println(cnfe.getMessage());
		}
		catch(SQLException sqle)
		{
			System.out.println(sqle.getMessage());
		}
	}
	public void desconectar(){
		try {
			if(con!=null){
				con.close();
				con = null;
			}
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}
}
