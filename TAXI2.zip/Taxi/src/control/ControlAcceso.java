package control;

import java.sql.*;
import entity.*;

public class ControlAcceso {
	private Connection con;
	
	public boolean validarIngreso(Cliente cliente) {
		conectar();
		boolean resultado = false;
		String login = cliente.getUsuario();
		String pass = cliente.getContrase�a();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Cliente WHERE login = '" + login + "' AND password = '" + pass + "'");
			while(rs.next()){
				resultado=true;
			}
			desconectar();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		return resultado;
	}
	
	public void conectar() {
		try
		{
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			String connectionUrl = "jdbc:sqlserver://148.239.60.34;" +  
					"databaseName=pfTaxiBautista;user=ids;password=ids4010;";
			con = DriverManager.getConnection(connectionUrl);
			System.out.println("Conectado");
		}
		catch(ClassNotFoundException cnfe)
		{
			System.out.println(cnfe.getMessage());
		}
		catch(SQLException sqle)
		{
			System.out.println(sqle.getMessage());
		}
	}
	
	public void desconectar() {
		try {
			if(con!=null){
				con.close();
				con = null;
			}
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}
}