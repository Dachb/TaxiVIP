package dibujarimagen;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

public class frameimagen extends JFrame implements ActionListener
{
	JButton boton,boton2,boton3,boton4;
	ImageIcon imagen,imagen2,imagen3,imagen4;
	Icon icono,icono2,icono3,icono4;
	JPanel panelInferior;
	panelimagen p;
	JDesktopPane escritorio;
	JMenuBar bmenu;
	JMenu menu,menu2,menu3;
	JMenuItem mitem,mitem2,mitem3,mitem4;
	formacercade formacercade;
	
	public frameimagen()
	{
	  this.setBounds(0,0,400,400);
	  this.setTitle("Taxi VIP");
	  Container c = getContentPane();
	   
	  
	  bmenu = new JMenuBar();
		menu = new JMenu("Inicio");
		menu2 = new JMenu("Mapas");
		menu3 = new JMenu("Acerca de");
		mitem = new JMenuItem ("Perfil");
		mitem3 = new JMenuItem ("Cerrar Sesion");
		mitem4 = new JMenuItem ("Configuracion");
		
		mitem2 = new JMenuItem ("Los mapas");
		
		
		menu.add(mitem);
		menu.add(mitem3);
		menu.add(mitem4);
	
		menu2.add(mitem2);
		
		bmenu.add(menu);
		bmenu.add(menu2);
		bmenu.add(menu3);
		
		this.setJMenuBar(bmenu);
		
		c = this.getContentPane();
		escritorio = new JDesktopPane();
		c.add(escritorio);
	  p=new panelimagen();
	  panelInferior = new JPanel();
	  panelInferior.setLayout(new FlowLayout());
	  boton=new JButton();
	  boton2=new JButton();
	  boton3=new JButton();
	  boton4=new JButton();
	  boton.setBounds(0,0,40,40);
	  boton2.setBounds(0,0,40,40);
	  boton3.setBounds(0,0,40,40);
	  boton4.setBounds(0,0,40,40);
	  
	  imagen = new ImageIcon(getClass().getResource("/dibujarimagen/borrar.jpg"));
	  imagen2 = new ImageIcon(getClass().getResource("/dibujarimagen/agregar.jpg"));
	  imagen3 = new ImageIcon(getClass().getResource("/dibujarimagen/buscar.png"));
	  imagen4 = new ImageIcon(getClass().getResource("/dibujarimagen/modificar.png"));
	  
	  icono = new ImageIcon(imagen.getImage().getScaledInstance(boton.getWidth(), boton.getHeight(), Image.SCALE_DEFAULT));
	  icono2 = new ImageIcon(imagen2.getImage().getScaledInstance(boton2.getWidth(), boton2.getHeight(), Image.SCALE_DEFAULT));
	  icono3 = new ImageIcon(imagen3.getImage().getScaledInstance(boton3.getWidth(), boton3.getHeight(), Image.SCALE_DEFAULT));
	  icono4 = new ImageIcon(imagen4.getImage().getScaledInstance(boton4.getWidth(), boton4.getHeight(), Image.SCALE_DEFAULT));
	  
	  boton.setIcon(icono);
	  boton2.setIcon(icono2);
	  boton3.setIcon(icono3);
	  boton4.setIcon(icono4);
	  
	  panelInferior.add(boton);
	  panelInferior.add(boton2);
	  panelInferior.add(boton3);
	  panelInferior.add(boton4);
	  
	  c.add(panelInferior,BorderLayout.SOUTH);
	 c.add(p,BorderLayout.CENTER);
	
	  
	  
		//add(new panelimagen());
		setSize(900,700);
		this.setLocationRelativeTo(null);
		setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==mitem)
		{
			formacercade = new formacercade();
			escritorio.add(formacercade);
		}
		
	}

}