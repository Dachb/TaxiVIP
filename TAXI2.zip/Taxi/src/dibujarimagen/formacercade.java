package dibujarimagen;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;



public class formacercade  extends JInternalFrame{
	private JPanel panelMatriz;
	private JLabel l1,l2,l3,l4,l5,l6,l7,l8;
	private JTextField t1,t2,t3,t4,t5,t6,t7,t8;
	panelacercade x;
	private Container c;

	
	public formacercade()
	{
		super("Contacto",true,true,true,true);
		this.setBounds(0,0,400,400);
		c = this.getContentPane();
		

		
		panelMatriz = new JPanel();
		x= new panelacercade ();
		
		 c.add(x,BorderLayout.CENTER);
		 
		 pack();
		 setSize(900,700);
	
		this.setVisible(true);
		
	}
	


	public static void main (String[] args) 
	{
	
		formacercade f = new formacercade();
	
	}
}

