package dibujarimagen;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class FormContacto extends JFrame
{
	private JPanel panelInferior,panelMatriz;
	private JLabel l1,l2,l3,l4,l5,l6,l7,l8;
	private JTextField t1,t2,t3,t4,t5,t6,t7,t8;
	private JButton b1,b2,b3;
	private Container c;

	
	public FormContacto()
	{
		super();
		c = this.getContentPane();
		
		l1 = new JLabel("Id");
		l2 = new JLabel("Nombre de Contacto");
		l3 = new JLabel("Nombre de Universidad");
		l4 = new JLabel("Nombre de Escuela");
		l5 = new JLabel("Telefono");
		l6 = new JLabel("E-mail");
		l7 = new JLabel("Latitud");
		l8 = new JLabel("Longitud");
		
		t1 = new JTextField(20);
		t2 = new JTextField(20);
		t3 = new JTextField(20);
		t4 = new JTextField(20);
		t5 = new JTextField(20);
		t6 = new JTextField(20);
		t7 = new JTextField(20);
		t8 = new JTextField(20);
		
		b1 = new JButton("Agregar");
		//b1.addActionListener(this);
		b2 = new JButton("Consultar");
		//b2.addActionListener(this);
		b3 = new JButton("Eliminar");
		//b3.addActionListener(this);
		
		panelInferior = new JPanel();
		panelInferior.setLayout(new FlowLayout());
		panelMatriz = new JPanel();
		panelMatriz.setLayout(new GridLayout(10,2));
		
		panelMatriz.add(l1);
		panelMatriz.add(t1);
		panelMatriz.add(l2);
		panelMatriz.add(t2);
		panelMatriz.add(l3);
		panelMatriz.add(t3);
		panelMatriz.add(l4);
		panelMatriz.add(t4);
		panelMatriz.add(l5);
		panelMatriz.add(t5);
		panelMatriz.add(l6);
		panelMatriz.add(t6);
		panelMatriz.add(l7);
		panelMatriz.add(t7);
		panelMatriz.add(l8);
		panelMatriz.add(t8);
		
		panelInferior.add(b1);
		panelInferior.add(b2);
		panelInferior.add(b3);
		
		c.setLayout(new BorderLayout());
		c.add(panelMatriz,BorderLayout.CENTER);
		c.add(panelInferior,BorderLayout.SOUTH);
		
		pack();
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setVisible(true);
		
	}
	
	public static void main (String[] args) 
	{
	
		FormContacto f = new FormContacto();
	
	}
	
	
	/*public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource()==b1)
		{
			Contacto contacto = new Contacto();
			contacto.setidacademia(Integer.parseInt(t1.getText()));
			contacto.setncontacto(t2.getText());
			contacto.setnunversidad(t3.getText());
			contacto.setnescuela(t4.getText());
			contacto.settelefono(Integer.parseInt(t5.getText()));
			contacto.setemail(t6.getText());
			contacto.setlatitud(Float.parseFloat(t7.getText()));
			contacto.setlongitud(Float.parseFloat(t8.getText())); 
			int resultado = control.insertarContacto(contacto);
			if(resultado>0)
			{
				JOptionPane.showMessageDialog(null,"Contacto agregada");
				t1.setText("");
				t2.setText("");
				t3.setText("");
				t4.setText("");
				t5.setText("");
				t6.setText("");
				t7.setText("");
				t8.setText("");
			}
			else
			{
				JOptionPane.showMessageDialog(null,"Contacto no agregada");
				t1.setText("");
				t2.setText("");
				t3.setText("");
				t4.setText("");
				t5.setText("");
				t6.setText("");
				t7.setText("");
				t8.setText("");
			}
		}
			if(e.getSource()==b2)
			{
				Contacto Contacto = new Contacto();
				Contacto.setidacademia(Integer.parseInt(t1.getText()));
				Contacto= control.consultarContacto(Contacto);
				
					t2.setText(Contacto.getncontacto());
					t3.setText(Contacto.getnunversidad());
					t4.setText(Contacto.getnescuela());
					t5.setText(Integer.toString(Contacto.gettelefono()));
					t6.setText(Contacto.getemail());
					t7.setText(Float.toString(Contacto.getlatitud()));
					t8.setText(Float.toString(Contacto.getlongitud()));
			}
	
		if (e.getSource()==b3)
		{
			Contacto Contacto = new Contacto();
			Contacto.setidacademia(Integer.parseInt(t1.getText()));
			int resultado= control.eliminarContacto(Contacto);
			if (resultado>0)
			{
				JOptionPane.showMessageDialog(null,"Contacto borrado");
			}
			else
			{
				JOptionPane.showMessageDialog(null,"Contacto borrado");
			}
			
		}
	
	}*/
}

			
			
		
		
	
